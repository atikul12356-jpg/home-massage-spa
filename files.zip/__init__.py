import os
import uuid
from functools import wraps
from flask import session, redirect, url_for, current_app
from werkzeug.utils import secure_filename


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated


def allowed_file(filename):
    allowed = current_app.config['ALLOWED_EXTENSIONS']
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed


def save_upload(file):
    if not file or file.filename == '':
        return None
    if not allowed_file(file.filename):
        return None
    ext = file.filename.rsplit('.', 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    safe_name = secure_filename(unique_name)
    upload_path = current_app.config['UPLOAD_FOLDER']
    os.makedirs(upload_path, exist_ok=True)
    file.save(os.path.join(upload_path, safe_name))
    return safe_name


def delete_upload(filename):
    if filename and filename != 'default.jpg':
        path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        if os.path.exists(path):
            os.remove(path)


def get_settings(db_query_fn):
    rows = db_query_fn("SELECT key, value FROM settings")
    return {r['key']: r['value'] for r in rows}
