from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import query_db, execute_db
from utils import get_settings

booking_bp = Blueprint('booking', __name__)


@booking_bp.route('/', methods=['GET', 'POST'])
@booking_bp.route('/<int:pkg_id>', methods=['GET', 'POST'])
def book(pkg_id=None):
    settings = get_settings(query_db)
    package = None
    if pkg_id:
        package = query_db("SELECT * FROM packages WHERE id=? AND is_active=1", (pkg_id,), one=True)

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        email = request.form.get('email', '').strip()
        address = request.form.get('address', '').strip()
        preferred_date = request.form.get('preferred_date', '').strip()
        message = request.form.get('message', '').strip()
        selected_pkg_id = request.form.get('package_id') or pkg_id
        pkg_name = ''

        if selected_pkg_id:
            pkg = query_db("SELECT name FROM packages WHERE id=?", (selected_pkg_id,), one=True)
            if pkg:
                pkg_name = pkg['name']

        errors = []
        if not name: errors.append('Name is required.')
        if not phone: errors.append('Phone is required.')
        if not email: errors.append('Email is required.')
        if not address: errors.append('Address is required.')
        if not preferred_date: errors.append('Preferred date is required.')

        if errors:
            for e in errors:
                flash(e, 'danger')
            return render_template('public/booking.html', package=package, settings=settings)

        booking_id = execute_db(
            "INSERT INTO bookings (package_id, package_name, name, phone, email, address, preferred_date, message) VALUES (?,?,?,?,?,?,?,?)",
            (selected_pkg_id, pkg_name, name, phone, email, address, preferred_date, message)
        )
        return redirect(url_for('booking.success', booking_id=booking_id))

    return render_template('public/booking.html', package=package, settings=settings)


@booking_bp.route('/success/<int:booking_id>')
def success(booking_id):
    settings = get_settings(query_db)
    booking = query_db("SELECT * FROM bookings WHERE id=?", (booking_id,), one=True)
    if not booking:
        return redirect(url_for('public.home'))
    return render_template('public/booking_success.html', booking=booking, settings=settings)
