import sqlite3
import os
from flask import g, current_app
from werkzeug.security import generate_password_hash


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def execute_db(query, args=()):
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    return cur.lastrowid


def init_db():
    db_path = current_app.config['DATABASE']
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")

    conn.executescript('''
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL
        );

        CREATE TABLE IF NOT EXISTS packages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            duration TEXT NOT NULL,
            image TEXT DEFAULT 'default.jpg',
            is_featured INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id)
        );

        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            package_id INTEGER,
            package_name TEXT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT NOT NULL,
            address TEXT NOT NULL,
            preferred_date TEXT NOT NULL,
            message TEXT,
            status TEXT DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (package_id) REFERENCES packages(id)
        );
    ''')
    conn.commit()
    conn.close()


def seed_data():
    db_path = current_app.config['DATABASE']
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    # Admin
    admin = conn.execute("SELECT id FROM admins WHERE email='admin@gmail.com'").fetchone()
    if not admin:
        conn.execute(
            "INSERT INTO admins (email, password_hash) VALUES (?, ?)",
            ('admin@gmail.com', generate_password_hash('admin123'))
        )

    # Default settings
    defaults = {
        'site_title': 'Home Massage Spa',
        'hero_title': 'Luxury Wellness\nDelivered to You',
        'hero_subtitle': 'Professional massage therapy at your home or our premium spa center.',
        'hero_image': '',
        'phone': '+8801995844839',
        'whatsapp': '+8801995844839',
        'footer_text': '© 2024 Home Massage Spa. All rights reserved.',
        'address': 'Dhaka, Bangladesh',
        'email': 'hello@homemassagespa.com',
    }
    for k, v in defaults.items():
        exists = conn.execute("SELECT key FROM settings WHERE key=?", (k,)).fetchone()
        if not exists:
            conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (k, v))

    # Categories
    cat_home = conn.execute("SELECT id FROM categories WHERE slug='home-service'").fetchone()
    if not cat_home:
        conn.execute("INSERT INTO categories (name, slug) VALUES (?, ?)", ('Home Service', 'home-service'))
    cat_spa = conn.execute("SELECT id FROM categories WHERE slug='spa-center'").fetchone()
    if not cat_spa:
        conn.execute("INSERT INTO categories (name, slug) VALUES (?, ?)", ('Spa Center', 'spa-center'))

    conn.commit()

    # Seed packages if none exist
    pkg_count = conn.execute("SELECT COUNT(*) FROM packages").fetchone()[0]
    if pkg_count == 0:
        home_id = conn.execute("SELECT id FROM categories WHERE slug='home-service'").fetchone()['id']
        spa_id = conn.execute("SELECT id FROM categories WHERE slug='spa-center'").fetchone()['id']

        packages = [
            (home_id, 'Swedish Relaxation', 'A full-body gentle massage that relieves muscle tension and promotes deep relaxation with warm aromatic oils.', 2500, '60 min', 1),
            (home_id, 'Deep Tissue Therapy', 'Targets chronic muscle knots and tension in deeper tissue layers. Ideal for athletes and desk workers.', 3200, '75 min', 1),
            (home_id, 'Hot Stone Massage', 'Volcanic basalt stones melt stress away while improving circulation and deeply relaxing muscle tissue.', 3800, '90 min', 1),
            (home_id, 'Couples Bliss', 'Share a luxurious side-by-side massage experience with your partner in the comfort of your home.', 5500, '60 min', 0),
            (spa_id, 'Royal Spa Ritual', 'Our signature multi-step treatment: exfoliation, hot towel, aromatherapy, and full body massage.', 5000, '120 min', 1),
            (spa_id, 'Aromatherapy Escape', 'Pure essential oils blended to your mood, paired with flowing massage strokes for total mind-body balance.', 3500, '60 min', 1),
            (spa_id, 'Prenatal Care', 'Specially designed safe massage for expecting mothers, relieving back pain and swelling with gentle care.', 3000, '60 min', 0),
            (spa_id, 'Foot Reflexology', 'Precise pressure techniques on reflex points of the feet to restore energy flow throughout the body.', 1800, '45 min', 0),
        ]
        for p in packages:
            conn.execute(
                "INSERT INTO packages (category_id, name, description, price, duration, is_featured) VALUES (?,?,?,?,?,?)",
                p
            )
        conn.commit()

    conn.close()
