from flask import Blueprint, render_template, abort
from database import query_db
from utils import get_settings

public_bp = Blueprint('public', __name__)


@public_bp.route('/')
def home():
    settings = get_settings(query_db)
    categories = query_db("SELECT * FROM categories ORDER BY id")
    packages_by_cat = {}
    for cat in categories:
        pkgs = query_db(
            "SELECT * FROM packages WHERE category_id=? AND is_active=1 ORDER BY is_featured DESC, sort_order ASC",
            (cat['id'],)
        )
        packages_by_cat[cat['id']] = {'category': cat, 'packages': pkgs}
    return render_template('public/home.html', settings=settings,
                           categories=categories, packages_by_cat=packages_by_cat)


@public_bp.route('/package/<int:pkg_id>')
def package_detail(pkg_id):
    settings = get_settings(query_db)
    package = query_db("SELECT p.*, c.name as cat_name FROM packages p JOIN categories c ON p.category_id=c.id WHERE p.id=? AND p.is_active=1", (pkg_id,), one=True)
    if not package:
        abort(404)
    return render_template('public/package_detail.html', package=package, settings=settings)
