from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from database import query_db, execute_db, get_db
from utils import login_required, get_settings, save_upload, delete_upload

admin_bp = Blueprint('admin', __name__)


# ── AUTH ──────────────────────────────────────────────────────────────────────

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'admin_id' in session:
        return redirect(url_for('admin.dashboard'))
    error = None
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        admin = query_db("SELECT * FROM admins WHERE email=?", (email,), one=True)
        if admin and check_password_hash(admin['password_hash'], password):
            session.permanent = True
            session['admin_id'] = admin['id']
            session['admin_email'] = admin['email']
            return redirect(url_for('admin.dashboard'))
        error = 'Invalid email or password.'
    return render_template('admin/login.html', error=error)


@admin_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('admin.login'))


# ── DASHBOARD ─────────────────────────────────────────────────────────────────

@admin_bp.route('/')
@admin_bp.route('/dashboard')
@login_required
def dashboard():
    settings = get_settings(query_db)
    total_packages = query_db("SELECT COUNT(*) as c FROM packages", one=True)['c']
    total_bookings = query_db("SELECT COUNT(*) as c FROM bookings", one=True)['c']
    pending = query_db("SELECT COUNT(*) as c FROM bookings WHERE status='Pending'", one=True)['c']
    recent_bookings = query_db("SELECT * FROM bookings ORDER BY created_at DESC LIMIT 5")
    return render_template('admin/dashboard.html', settings=settings,
                           total_packages=total_packages, total_bookings=total_bookings,
                           pending=pending, recent_bookings=recent_bookings)


# ── PACKAGES ──────────────────────────────────────────────────────────────────

@admin_bp.route('/packages')
@login_required
def packages():
    settings = get_settings(query_db)
    pkgs = query_db("SELECT p.*, c.name as cat_name FROM packages p JOIN categories c ON p.category_id=c.id ORDER BY p.category_id, p.sort_order")
    return render_template('admin/packages.html', packages=pkgs, settings=settings)


@admin_bp.route('/packages/add', methods=['GET', 'POST'])
@login_required
def package_add():
    settings = get_settings(query_db)
    categories = query_db("SELECT * FROM categories ORDER BY id")
    if request.method == 'POST':
        cat_id = request.form.get('category_id')
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        price = request.form.get('price', 0)
        duration = request.form.get('duration', '').strip()
        is_featured = 1 if request.form.get('is_featured') else 0
        is_active = 1 if request.form.get('is_active') else 0

        image_name = 'default.jpg'
        if 'image' in request.files:
            saved = save_upload(request.files['image'])
            if saved:
                image_name = saved

        execute_db(
            "INSERT INTO packages (category_id, name, description, price, duration, image, is_featured, is_active) VALUES (?,?,?,?,?,?,?,?)",
            (cat_id, name, description, price, duration, image_name, is_featured, is_active)
        )
        flash('Package added successfully.', 'success')
        return redirect(url_for('admin.packages'))
    return render_template('admin/package_form.html', package=None, categories=categories, settings=settings)


@admin_bp.route('/packages/edit/<int:pkg_id>', methods=['GET', 'POST'])
@login_required
def package_edit(pkg_id):
    settings = get_settings(query_db)
    categories = query_db("SELECT * FROM categories ORDER BY id")
    pkg = query_db("SELECT * FROM packages WHERE id=?", (pkg_id,), one=True)
    if not pkg:
        flash('Package not found.', 'danger')
        return redirect(url_for('admin.packages'))

    if request.method == 'POST':
        cat_id = request.form.get('category_id')
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        price = request.form.get('price', 0)
        duration = request.form.get('duration', '').strip()
        is_featured = 1 if request.form.get('is_featured') else 0
        is_active = 1 if request.form.get('is_active') else 0

        image_name = pkg['image']
        if 'image' in request.files and request.files['image'].filename:
            saved = save_upload(request.files['image'])
            if saved:
                delete_upload(pkg['image'])
                image_name = saved

        execute_db(
            "UPDATE packages SET category_id=?, name=?, description=?, price=?, duration=?, image=?, is_featured=?, is_active=? WHERE id=?",
            (cat_id, name, description, price, duration, image_name, is_featured, is_active, pkg_id)
        )
        flash('Package updated.', 'success')
        return redirect(url_for('admin.packages'))
    return render_template('admin/package_form.html', package=pkg, categories=categories, settings=settings)


@admin_bp.route('/packages/delete/<int:pkg_id>', methods=['POST'])
@login_required
def package_delete(pkg_id):
    pkg = query_db("SELECT * FROM packages WHERE id=?", (pkg_id,), one=True)
    if pkg:
        delete_upload(pkg['image'])
        execute_db("DELETE FROM packages WHERE id=?", (pkg_id,))
        flash('Package deleted.', 'success')
    return redirect(url_for('admin.packages'))


@admin_bp.route('/packages/toggle/<int:pkg_id>/<field>', methods=['POST'])
@login_required
def package_toggle(pkg_id, field):
    if field not in ('is_active', 'is_featured'):
        return redirect(url_for('admin.packages'))
    pkg = query_db(f"SELECT {field} FROM packages WHERE id=?", (pkg_id,), one=True)
    if pkg:
        new_val = 0 if pkg[field] else 1
        execute_db(f"UPDATE packages SET {field}=? WHERE id=?", (new_val, pkg_id))
    return redirect(url_for('admin.packages'))


# ── BOOKINGS ──────────────────────────────────────────────────────────────────

@admin_bp.route('/bookings')
@login_required
def bookings():
    settings = get_settings(query_db)
    status_filter = request.args.get('status', '')
    if status_filter:
        all_bookings = query_db("SELECT * FROM bookings WHERE status=? ORDER BY created_at DESC", (status_filter,))
    else:
        all_bookings = query_db("SELECT * FROM bookings ORDER BY created_at DESC")
    statuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled']
    return render_template('admin/bookings.html', bookings=all_bookings,
                           statuses=statuses, status_filter=status_filter, settings=settings)


@admin_bp.route('/bookings/status/<int:bid>', methods=['POST'])
@login_required
def booking_status(bid):
    new_status = request.form.get('status')
    allowed = ['Pending', 'Confirmed', 'Completed', 'Cancelled']
    if new_status in allowed:
        execute_db("UPDATE bookings SET status=? WHERE id=?", (new_status, bid))
    return redirect(url_for('admin.bookings'))


@admin_bp.route('/bookings/delete/<int:bid>', methods=['POST'])
@login_required
def booking_delete(bid):
    execute_db("DELETE FROM bookings WHERE id=?", (bid,))
    flash('Booking deleted.', 'success')
    return redirect(url_for('admin.bookings'))


@admin_bp.route('/bookings/view/<int:bid>')
@login_required
def booking_view(bid):
    settings = get_settings(query_db)
    booking = query_db("SELECT * FROM bookings WHERE id=?", (bid,), one=True)
    if not booking:
        flash('Booking not found.', 'danger')
        return redirect(url_for('admin.bookings'))
    statuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled']
    return render_template('admin/booking_view.html', booking=booking, statuses=statuses, settings=settings)


# ── SETTINGS ──────────────────────────────────────────────────────────────────

@admin_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def site_settings():
    settings = get_settings(query_db)
    if request.method == 'POST':
        fields = ['site_title', 'hero_title', 'hero_subtitle', 'phone', 'whatsapp',
                  'footer_text', 'address', 'email']
        for field in fields:
            val = request.form.get(field, '').strip()
            execute_db("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (field, val))

        if 'hero_image' in request.files and request.files['hero_image'].filename:
            saved = save_upload(request.files['hero_image'])
            if saved:
                execute_db("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", ('hero_image', saved))

        flash('Settings saved successfully.', 'success')
        return redirect(url_for('admin.site_settings'))

    return render_template('admin/settings.html', settings=settings)
