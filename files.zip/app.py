from flask import Flask
from config import Config
from database import init_db, seed_data
from controllers.public import public_bp
from controllers.booking import booking_bp
from controllers.admin import admin_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(public_bp)
    app.register_blueprint(booking_bp, url_prefix='/booking')
    app.register_blueprint(admin_bp, url_prefix='/admin')

    with app.app_context():
        init_db()
        seed_data()

    return app

app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
